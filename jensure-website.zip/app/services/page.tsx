import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Building,
  Coins,
  GraduationCap,
  LineChart,
  Presentation,
  Users,
} from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Services</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Tailored for Your Success - At Jensure, we offer a unique blend of financial and career-building
                solutions designed to meet your needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Solutions */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">Investment Solutions</h2>
            <p className="max-w-[900px] text-muted-foreground">
              Grow your wealth with confidence. Our experts provide personalized guidance on various investment options.
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:gap-12">
            <Card>
              <CardHeader className="pb-2">
                <LineChart className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Mutual Funds & SIPs</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Strategic investment plans tailored to your risk appetite and financial goals with regular monitoring
                  and rebalancing.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <BarChart3 className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Stock Market Investments</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Expert guidance on equity investments with research-backed recommendations and portfolio management.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Building className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Real Estate Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Identify promising real estate investments with thorough market analysis and due diligence support.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Coins className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Gold and Alternative Assets</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Diversify your portfolio with alternative investment options including gold, bonds, and other asset
                  classes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Internship Programs */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">Internship Programs</h2>
            <p className="max-w-[900px] text-muted-foreground">
              Kickstart your finance career with hands-on training in various financial disciplines.
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12">
            <Card>
              <CardHeader className="pb-2">
                <Presentation className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Equity Research</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Learn to analyze companies, sectors, and market trends to make informed investment recommendations.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <BookOpen className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Business Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Develop skills in business modeling, competitive analysis, and strategic planning for financial
                  decision-making.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <GraduationCap className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Financial Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Master financial statement analysis, valuation techniques, and financial modeling for investment
                  decisions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Consulting & Placement */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">Consulting & Placement</h2>
            <p className="max-w-[900px] text-muted-foreground">
              Personalized guidance for clients and career support for interns.
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:gap-12">
            <Card>
              <CardHeader>
                <Users className="h-10 w-10 text-primary mb-2" />
                <CardTitle>For Clients</CardTitle>
                <CardDescription>
                  Custom financial strategies to maximize returns and secure your future.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-sm text-muted-foreground">
                  <li>Personalized financial planning</li>
                  <li>Portfolio review and optimization</li>
                  <li>Tax planning strategies</li>
                  <li>Retirement planning</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/contact">Get Started</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <GraduationCap className="h-10 w-10 text-primary mb-2" />
                <CardTitle>For Interns</CardTitle>
                <CardDescription>
                  Career support, resume building, and placement assistance with top firms.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-sm text-muted-foreground">
                  <li>Resume and portfolio development</li>
                  <li>Interview preparation</li>
                  <li>Industry connections and networking</li>
                  <li>Placement assistance with partner firms</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/contact">Apply Now</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Why It Works</h2>
              <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We combine affordability, expertise, and real-world focus to deliver results—whether it's growing your
                savings or landing your dream job.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/contact">
                  Get Started Today <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
