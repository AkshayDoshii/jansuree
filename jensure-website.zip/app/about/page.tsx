import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, BarChart3, GraduationCap, Target } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Who We Are</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Founded in April 2025, Jensure is redefining financial success by blending expert investment solutions
                with a passion for nurturing talent. Based in India, we're on a mission to make wealth creation
                accessible and empower the next generation of finance leaders.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold tracking-tighter">Our Mission</h2>
              <p className="text-muted-foreground md:text-xl">
                To simplify financial growth for everyone—clients seeking prosperity and students chasing
                careers—through one dynamic ecosystem built on trust, expertise, and opportunity.
              </p>
            </div>
            <div className="mx-auto lg:mx-0">
              <div className="aspect-video rounded-xl bg-muted/50 overflow-hidden">
                <img
                  src="/placeholder.svg?height=600&width=800"
                  alt="Team collaboration"
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What Sets Us Apart */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">What Sets Us Apart</h2>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12">
            <Card>
              <CardHeader className="pb-2">
                <BarChart3 className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Financial Expertise</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  From mutual funds to real estate, we guide you with clarity and precision.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <GraduationCap className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Education Focus</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Our internship programs equip students with practical skills for the finance world.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Target className="h-10 w-10 text-primary mb-2" />
                <CardTitle>Real Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Affordable, transparent solutions that deliver results for your wallet and your career.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="mx-auto lg:mx-0 order-2 lg:order-1">
              <div className="aspect-video rounded-xl bg-muted/50 overflow-hidden">
                <img
                  src="/placeholder.svg?height=600&width=800"
                  alt="Future vision"
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
            <div className="space-y-4 order-1 lg:order-2">
              <h2 className="text-3xl font-bold tracking-tighter">Our Vision</h2>
              <p className="text-muted-foreground md:text-xl">
                To become India's leading platform for financial empowerment and talent development—driving wealth for
                clients and success for students, one step at a time.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button asChild>
                  <Link href="/contact">
                    Meet the Team <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
